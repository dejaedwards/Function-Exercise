import Cocoa

var str = "Hello, Playground"

func addition() {
    let a = 12
    let b = 13
    let c = a + b
    print(c)
}
addition()


//Correct one
    func addTwoNum(num1: Int, num2: Int) -> Int {
        var total = 0
        total = num1 + num2
        
        return total
}
    var totalNumber = addTwoNum(num1: 6, num2: 4)
        





